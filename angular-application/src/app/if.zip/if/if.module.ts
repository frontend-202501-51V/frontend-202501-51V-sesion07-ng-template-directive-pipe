import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IfRoutingModule } from './if-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IfRoutingModule
  ]
})
export class IfModule { }
