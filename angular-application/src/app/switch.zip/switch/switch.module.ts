import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SwitchRoutingModule } from './switch-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SwitchRoutingModule
  ]
})
export class SwitchModule { }
